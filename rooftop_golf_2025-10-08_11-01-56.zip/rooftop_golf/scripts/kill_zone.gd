extends Area2D

# This function is called when a body enters the kill zone.
# The signal is connected in the kill_zone.tscn scene file.
func _on_body_entered(body: Node2D) -> void:
	# Check if the body that entered is the ball.
	# We do this by checking if the body is in the "ball" group.
	if not body.is_in_group("ball"):
		return # Not the ball, so we do nothing.

	# Find the spawn point in the level.
	# We assume the kill_zone is a direct child of the level scene,
	# and that the level scene has a Marker2D named "spawn_ball".
	var spawn_point = get_parent().get_node_or_null("spawn_ball")
	
	if not spawn_point:
		push_error("Could not find spawn_ball marker in the level scene!")
		return

	# Reset the ball's position to the spawn point.
	body.global_position = spawn_point.global_position
	
	# Reset the ball's velocity to zero.
	body.velocity = Vector2.ZERO
	
	print("Ball entered kill zone and was respawned.")