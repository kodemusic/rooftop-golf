extends Node2D

signal goal_scored

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass


func _on_goal_cup_body_entered(body: Node2D) -> void:
	if body.is_in_group("ball"):
		print("Goal! Ball entered the cup!")
		goal_scored.emit()
		body.call_deferred("queue_free")
