extends CanvasLayer

@onready var score_label: Label = $score_label

var score: int = 0

func _ready() -> void:
	update_score_label()

func increment_score() -> void:
	score += 1
	update_score_label()

func update_score_label() -> void:
	score_label.text = "Score: " + str(score)

func reset_score() -> void:
    score = 0
    update_score_label()