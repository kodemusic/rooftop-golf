extends CharacterBody2D

@onready var trail_line = $Line2D

# Dot trail pool
#var dot_texture = preload("res://assets/trail.png")
var dot_pool: Array = []
var pool_size: int = 140
var pool_index: int = 0

# Spacing in pixels between dots along the path
var dot_spacing: float = 24.0
var last_dot_pos = null

@export_group("Physics")
@export var max_speed = 800.0  # Maximum ball speed for arcade feel
@export var air_resistance = 0.98  # Slow down factor (0.98 = 2% slowdown per frame)
@export var min_velocity_threshold = 10.0  # Speed below which ball stops
@export var gravity_force := 900.0
@export var gravity_scale := 0.5
var debug_traces: bool = false  # Set to true for debugging
var allow_impulse: bool = false
var allow_impulse_timer: float = 0.0
var allow_impulse_window: float = 0.2
var is_active: bool = false  # Prevent physics until first shot

func _ready():
	add_to_group("ball")
	# hide the Line2D (we use sprites for dotted trail)
	if trail_line:
		trail_line.visible = false

	# Arcade-style physics settings (CharacterBody2D-style)
	gravity_scale = gravity_scale

	# Create pooled sprites for dotted trail. Choose a robust parent so dots are in world space
	# If the ball is nested under a Character2D (or other), prefer the current scene root for stable world coords.
	var dots_parent = null
	var scene_root = get_tree().get_current_scene()
	if scene_root:
		dots_parent = scene_root
	elif get_parent():
		dots_parent = get_parent()
	else:
		dots_parent = get_tree().get_root()

	for i in range(pool_size):
		var s = Sprite2D.new()
		#s.texture = dot_texture
		s.visible = false
		s.centered = true
		s.z_index = 100
		# Use deferred add_child to avoid 'parent busy' errors in editor/runtime
		dots_parent.call_deferred("add_child", s)
		dot_pool.append(s)

func _physics_process(delta: float) -> void:
	# Don't apply physics until ball is shot
	if not is_active:
		return

	if debug_traces:
		print("[ball] START frame: velocity=", velocity, " pos=", global_position)

	# Apply gravity
	velocity.y += gravity_force * gravity_scale * delta

	# Clamp max speed
	if velocity.length() > max_speed:
		velocity = velocity.normalized() * max_speed

	# Apply air resistance for arcade feel
	if velocity.length() > min_velocity_threshold:
		velocity *= pow(air_resistance, delta * 60.0)
	else:
		# Stop the ball if moving too slowly
		velocity = Vector2.ZERO

	if debug_traces:
		print("[ball] BEFORE move_and_slide: velocity=", velocity)

	# Move the CharacterBody2D
	move_and_slide()

	if debug_traces:
		print("[ball] AFTER move_and_slide: velocity=", velocity, " pos=", global_position, " is_on_floor=", is_on_floor(), " is_on_wall=", is_on_wall())

	# Update allow_impulse timer
	if allow_impulse:
		allow_impulse_timer += delta
		if allow_impulse_timer > allow_impulse_window:
			allow_impulse = false
			allow_impulse_timer = 0.0

	# Place dots along the path at fixed spacing
	if velocity.length() > 5:  # if moving
		var pos = global_position
		if last_dot_pos == null:
			_place_dot(pos)
		elif pos.distance_to(last_dot_pos) >= dot_spacing:
			_place_dot(pos)
	# Debugging velocity
	#print("[ball] velocity=", velocity)

func _place_dot(pos: Vector2) -> void:
	# Place next dot from the pool at world position 'pos'
	if dot_pool.size() == 0:
		return
	var s: Sprite2D = dot_pool[pool_index]
	pool_index = (pool_index + 1) % pool_size
	s.global_position = pos
	s.visible = true
	last_dot_pos = pos

func apply_impulse(impulse: Vector2) -> void:
	# Compatibility helper for game_mode which previously called apply_impulse on a RigidBody2D
	if not allow_impulse:
		if debug_traces:
			print("[ball] apply_impulse ignored (allow_impulse=false) impulse=", impulse)
		return
	# consume the guard
	allow_impulse = false
	allow_impulse_timer = 0.0
	# Activate the ball physics when first shot
	is_active = true
	velocity += impulse
	print("[ball] apply_impulse: impulse=", impulse, " new_velocity=", velocity)
	
func clear_trail():
	# Hide all pooled dots and reset state
	for s in dot_pool:
		s.visible = false
	last_dot_pos = null
	pool_index = 0
