extends Node2D

@onready var ball = $level_1/ball
@onready var user_ui = $UserUI
@onready var aim_line = $AimLine

var aiming = false
var current_power = 0.0

@export_group("Aiming")
@export var max_power = 500.0
@export var max_dist = 500.0
@export var trajectory_power_scale = 4.0
@export var trajectory_length_factor = 0.2

var dash_length = 10.0
var gap_length = 5.0

# Trajectory prediction settings
var max_trajectory_points = 500
var trajectory_step = 0.05
var trajectory_cache = []
var min_trajectory_steps = 10

func _ready() -> void:
	aim_line.visible = false
	$level_1/goal.goal_scored.connect(_on_goal_scored)

func _process(_delta: float) -> void:
	if aiming:
		update_aim_line()
		aim_line.visible = true
	else:
		aim_line.visible = false

func _input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			# Only allow aiming if the ball is stopped.
			if ball.velocity.length() < ball.min_velocity_threshold:
				aiming = true
		else:
			if aiming:
				shoot()
			aiming = false

func shoot():
	ball.clear_trail()
	var direction = (get_global_mouse_position() - ball.global_position).normalized()
	ball.allow_impulse = true
	ball.allow_impulse_timer = 0.0
	ball.apply_impulse(direction * current_power)

func update_aim_line():
	var mouse_pos = get_global_mouse_position()
	var ball_pos = ball.global_position
	
	var direction = (mouse_pos - ball_pos).normalized()
	
	# Power is based on distance from mouse to ball
	var distance = mouse_pos.distance_to(ball_pos)
	current_power = (distance / max_dist) * max_power
	current_power = clamp(current_power, 0, max_power)

	trajectory_cache.clear()
	
	var start_pos = ball_pos
	var cs = ball.get_node_or_null("CollisionShape2D")
	if cs and cs.shape:
		if cs.shape is CircleShape2D:
			var radius_world = cs.shape.radius * cs.global_transform.get_scale().y
			start_pos += Vector2(0, -radius_world)

	# Simulate trajectory to match ball's physics
	var sim_pos = start_pos
	var sim_vel = direction * current_power * trajectory_power_scale
	
	var trajectory_time_step = 0.05 # Same as trajectory_step

	var num_points = int(floor(current_power * trajectory_length_factor))
	if num_points < min_trajectory_steps:
		num_points = min_trajectory_steps
	if num_points > max_trajectory_points:
		num_points = max_trajectory_points

	for i in range(num_points):
		trajectory_cache.append(sim_pos)

		# Apply gravity
		sim_vel.y += ball.gravity_force * ball.gravity_scale * trajectory_time_step

		# Clamp max speed
		if sim_vel.length() > ball.max_speed:
			sim_vel = sim_vel.normalized() * ball.max_speed

		# Apply air resistance
		if sim_vel.length() > ball.min_velocity_threshold:
			sim_vel *= pow(ball.air_resistance, trajectory_time_step * 60.0)
		else:
			sim_vel = Vector2.ZERO
		
		# Update position
		sim_pos += sim_vel * trajectory_time_step

		if sim_vel.length() < 1:
			break

	var dotted_points = PackedVector2Array()
	var i = 0
	while i < trajectory_cache.size():
		dotted_points.append(aim_line.to_local(trajectory_cache[i]))
		var step = 1 + int(i / 15) 
		i += step
	aim_line.points = dotted_points


func _on_goal_scored():
	print("Goal scored! Loading next level.")
	user_ui.increment_score()
	_load_next_level()

func _load_next_level():
	# This is where you would put your logic to load the next level.
	# For now, we will just reload the current scene as a placeholder.
	# Example: get_tree().change_scene_to_file("res://scenes/level_2.tscn")
	get_tree().reload_current_scene()
