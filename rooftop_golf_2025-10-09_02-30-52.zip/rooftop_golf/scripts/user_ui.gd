extends Control

var score_label: Label

var score: int = 0

func _ready() -> void:
	# Safely get the score label node
	score_label = get_node_or_null("score_label")
	if not score_label:
		push_warning("UserUI: score_label not found in scene tree")
	update_score_label()

func increment_score() -> void:
	score += 1
	update_score_label()

func update_score_label() -> void:
	if score_label:
		score_label.text = "Score: " + str(score)

func reset_score() -> void:
	score = 0
	update_score_label()
