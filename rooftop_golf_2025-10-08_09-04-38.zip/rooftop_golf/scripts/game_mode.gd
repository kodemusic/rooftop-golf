extends Node2D

var ball: CharacterBody2D
var user_ui: CanvasLayer
var aim_line: Line2D
var level_manager: Node2D

var aiming = false
var current_power = 0.0

@export_group("Aiming")
@export var max_power = 500.0
@export var max_dist = 500.0
@export var trajectory_power_scale = 4.0
@export var trajectory_length_factor = 0.2

var dash_length = 10.0
var gap_length = 5.0

# Trajectory prediction settings
var max_trajectory_points = 500
var trajectory_step = 0.05
var trajectory_cache = []
var min_trajectory_steps = 10

func _ready() -> void:
	ball = $level_1/ball
	user_ui = $UserUI
	aim_line = $level_1/aim_line
	level_manager = $level_1/level_manager
	
	# Use level manager for spawn position if available
	if level_manager:
		# Level manager will handle spawn position
		if ball:
			# Connect idle timeout signal
			ball.idle_timeout_reached.connect(respawn_ball)
	else:
		# Fallback to old method if no level manager
		push_warning("No level_manager found, using ball's initial position")
	
	if aim_line:
		aim_line.visible = false
	
	if $level_1/goal:
		$level_1/goal.goal_scored.connect(_on_goal_scored)
	
	# Connect kill zone if it exists
	if $level_1/kill_zone:
		$level_1/kill_zone.body_entered.connect(_on_kill_zone_entered)

func _process(_delta: float) -> void:
	if aiming:
		update_aim_line()
		if aim_line:
			aim_line.visible = true
	else:
		if aim_line:
			aim_line.visible = false

func _input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			# Only allow aiming if the ball is stopped.
			if ball and ball.velocity.length() < ball.min_velocity_threshold:
				aiming = true
		else:
			if aiming:
				shoot()
			aiming = false

func shoot():
	if not ball:
		return
	ball.clear_trail()
	var direction = (get_global_mouse_position() - ball.global_position).normalized()
	ball.allow_impulse = true
	ball.allow_impulse_timer = 0.0
	ball.apply_impulse(direction * current_power)

func update_aim_line():
	if not aim_line:
		return
	
	var mouse_pos = get_global_mouse_position()
	var ball_pos = ball.global_position
	
	var direction = (mouse_pos - ball_pos).normalized()
	
	# Power is based on distance from mouse to ball
	var distance = mouse_pos.distance_to(ball_pos)
	current_power = (distance / max_dist) * max_power
	current_power = clamp(current_power, 0, max_power)

	trajectory_cache.clear()
	
	var start_pos = ball_pos
	var cs = ball.get_node_or_null("CollisionShape2D")
	if cs and cs.shape:
		if cs.shape is CircleShape2D:
			var radius_world = cs.shape.radius * cs.global_transform.get_scale().y
			start_pos += Vector2(0, -radius_world)

	# Simulate trajectory to match ball's physics
	var sim_pos = start_pos
	var sim_vel = direction * current_power * trajectory_power_scale
	
	var trajectory_time_step = 0.05 # Same as trajectory_step

	var num_points = int(floor(current_power * trajectory_length_factor))
	if num_points < min_trajectory_steps:
		num_points = min_trajectory_steps
	if num_points > max_trajectory_points:
		num_points = max_trajectory_points

	for i in range(num_points):
		trajectory_cache.append(sim_pos)

		# Apply gravity
		sim_vel.y += ball.gravity_force * ball.gravity_scale * trajectory_time_step

		# Clamp max speed
		if sim_vel.length() > ball.max_speed:
			sim_vel = sim_vel.normalized() * ball.max_speed

		# Apply air resistance
		if sim_vel.length() > ball.min_velocity_threshold:
			sim_vel *= pow(ball.air_resistance, trajectory_time_step * 60.0)
		else:
			sim_vel = Vector2.ZERO
		
		# Update position
		sim_pos += sim_vel * trajectory_time_step

		if sim_vel.length() < 1:
			break

	var dotted_points = PackedVector2Array()
	var i = 0
	while i < trajectory_cache.size():
		dotted_points.append(aim_line.to_local(trajectory_cache[i]))
		var step = 1 + int(i / 15) 
		i += step
	aim_line.points = dotted_points


func _on_goal_scored():
	print("Goal scored! Loading next level.")
	if user_ui:
		user_ui.increment_score()
	_load_next_level()

func _load_next_level():
	# This is where you would put your logic to load the next level.
	# For now, we will just reload the current scene as a placeholder.
	# Example: get_tree().change_scene_to_file("res://scenes/level_2.tscn")
	get_tree().reload_current_scene()

func respawn_ball():
	if not ball:
		return
	
	# Use level manager to respawn if available
	if level_manager:
		level_manager.spawn_ball_at_spawn_point()
	else:
		# Fallback: just reset velocity and clear trail
		push_warning("No level_manager, ball position not reset")
		ball.velocity = Vector2.ZERO
		ball.is_active = false
		ball.clear_trail()
		ball.idle_timer = 0.0

func _on_kill_zone_entered(body):
	# Check if the ball entered the kill zone
	if body == ball:
		print("Ball entered kill zone!")
		respawn_ball()
